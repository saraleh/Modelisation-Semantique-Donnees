import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.sparql.vocabulary.FOAF;
import org.apache.jena.util.FileManager;
import org.apache.jena.vocabulary.DCTerms;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.SchemaDO;
import org.apache.jena.vocabulary.VCARD;

import javax.xml.validation.Schema;
import java.io.InputStream;

public class Jena {

    public static void main(String[] args) {



// créer un modèle vide
        Model model = ModelFactory.createDefaultModel();


// créer la ressource
//   et ajouter des propriétés en cascade
        Resource jupiter
                = model.createResource("https://www.edmu.fr/p/mozart-symphonie-jupiter.html")
                .addProperty(DCTerms.title, "Jupiter")
                .addProperty(RDF.type, "Oeuvres")
                .addProperty(SchemaDO.category ,"Symphonie")
                .addProperty(SchemaDO.composer,
                        model.createResource()
                                .addProperty(FOAF.homepage, "https://fr.wikipedia.org/wiki/Wolfgang_Amadeus_Mozart")
                                .addProperty( SchemaDO.name,"Wolfgang Amadeus Mozart" ))
                .addProperty(SchemaDO.track,
                        model.createResource()
                                .addProperty(SchemaDO.name, "Molto Allegro" )
                                .addProperty(SchemaDO.name, "Menuetto")
                                .addProperty(SchemaDO.name, "AndanteCantabile" )
                                .addProperty(SchemaDO.name, "Allegro Vivace"))
               .addProperty(SchemaDO.musicReleaseFormat,

                        model.createResource()
                                .addProperty(SchemaDO.addressRegion, "Londres")
                                .addProperty( SchemaDO.yearBuilt , "1980")
                                        .addProperty( SchemaDO.director,
                                                model.createResource()
                                                        .addProperty( SchemaDO.musicGroupMember, "Orchestre symphonique")
                                                        .addProperty(FOAF.homepage, "https://fr.wikipedia.org/wiki/Claudio_Abbado" )
                                                        .addProperty(SchemaDO.name, "Claudio Abbado")));


System.out.println("Le résultat en Turtle");
model.write(System.out, "TURTLE");


System.out.println("Le résultat en XML");
model.write(System.out, "RDF/XML-ABBREV");

System.out.println("Le résultat en JSON");
model.write(System.out, "RDF/JSON");
       

    }
}
